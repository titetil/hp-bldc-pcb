Board Name:  HP BLDC PCB, v1.1

Company:  TI Automotive

Thickness:  0.062"

Number of Layers:  4

F.Cu: Base Copper: 35 um, Platting: 35 um
In1.Cu: Base Copper: 70 um
In2.Cu: Base Copper: 70 um
B.Cu: Base Copper: 35 um, Platting: 35 um

